Shape zip file created in TestKmlMediateSupport.testRoundTrip()
by executing the statement { Mediator.exportShpLayers(new File("testLayersShp.zip"), layers) }
after the layers are constructed.

This file should match exactly the KML file in data/kml/MultiGeometry/testLayers.kml
which was produced from the same feature/layer structure.
